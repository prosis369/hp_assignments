Execution:

1. Run the cpp file along with the -fcilkplus flag and clang command.
2. ./a.out